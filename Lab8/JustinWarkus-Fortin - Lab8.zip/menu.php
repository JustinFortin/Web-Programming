<?php

echo "<a href='http://www.justinfortin.ca/CST8238/Lab8/input.php'>Input</a>"." ";
echo "<a href='http://www.justinfortin.ca/CST8238/Lab6/session1.php'>Session 1</a>"." ";
echo "<a href='http://www.justinfortin.ca/CST8238/Lab6/session2.php'>Session 2</a>"." ";
?>