<?php

define("STUDENT_NUM", "040966794");
echo "Student Number: ".STUDENT_NUM;
echo "<br>Email: wark0025@algonquinlive.com";

?>